import React from 'react'
import ReactDOM from 'react-dom/client'
import MayajStore from './MayajStore.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MayajStore />
  </React.StrictMode>,
)
