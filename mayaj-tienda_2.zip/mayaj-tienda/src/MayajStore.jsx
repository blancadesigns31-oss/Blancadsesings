import React, { useState, useEffect } from 'react';
import { ShoppingBag, Plus, Trash2, Upload, Settings, Package, TrendingUp, Facebook, Instagram, MessageCircle, Music2, Edit3, Check, ArrowLeft, CreditCard, Truck, Eye, EyeOff, Lock } from 'lucide-react';

// Storage adapter usando localStorage
const storage = {
  get: (key) => {
    const val = localStorage.getItem(key);
    return val ? { value: val } : null;
  },
  set: (key, value) => {
    localStorage.setItem(key, value);
    return { value };
  }
};

const DEPARTAMENTOS_GT = {
  "Alta Verapaz": ["Cobán","Santa Cruz Verapaz","San Cristóbal Verapaz","Tactic","Tamahú","Tucurú","Panzós","Senahú","San Pedro Carchá","San Juan Chamelco","Lanquín","Cahabón","Chisec","Chahal","Fray Bartolomé de las Casas","Santa Catalina La Tinta","Raxruhá"],
  "Baja Verapaz": ["Salamá","San Miguel Chicaj","Rabinal","Cubulco","Granados","Santa Cruz El Chol","San Jerónimo","Purulhá"],
  "Chimaltenango": ["Chimaltenango","San José Poaquil","San Martín Jilotepeque","Comalapa","Santa Apolonia","Tecpán Guatemala","Patzún","Pochuta","Patzicía","Santa Cruz Balanyá","Acatenango","Yepocapa","San Andrés Itzapa","Parramos","Zaragoza","El Tejar"],
  "Chiquimula": ["Chiquimula","San José La Arada","San Juan Ermita","Jocotán","Camotán","Olopa","Esquipulas","Concepción Las Minas","Quezaltepeque","San Jacinto","Ipala"],
  "El Progreso": ["Guastatoya","Morazán","San Agustín Acasaguastlán","San Cristóbal Acasaguastlán","El Jícaro","Sansare","Sanarate","San Antonio La Paz"],
  "Escuintla": ["Escuintla","Santa Lucía Cotzumalguapa","La Democracia","Siquinalá","Masagua","Tiquisate","La Gomera","Guanagazapa","San José","Iztapa","Palín","San Vicente Pacaya","Nueva Concepción"],
  "Guatemala": ["Guatemala","Santa Catarina Pinula","San José Pinula","San José del Golfo","Palencia","Chinautla","San Pedro Ayampuc","Mixco","San Pedro Sacatepéquez","San Juan Sacatepéquez","San Raymundo","Chuarrancho","Fraijanes","Amatitlán","Villa Nueva","Villa Canales","San Miguel Petapa"],
  "Huehuetenango": ["Huehuetenango","Chiantla","Malacatancito","Cuilco","Nentón","San Pedro Necta","Jacaltenango","Soloma","Ixtahuacán","Santa Bárbara","La Libertad","La Democracia","San Miguel Acatán","San Rafael La Independencia","Todos Santos Cuchumatán","San Juan Atitán","Santa Eulalia","San Mateo Ixtatán","Colotenango","San Sebastián Huehuetenango","Tectitán","Concepción Huista","San Juan Ixcoy","San Antonio Huista","San Sebastián Coatán","Barillas","Aguacatán","San Rafael Petzal","San Gaspar Ixchil","Santiago Chimaltenango","Santa Ana Huista","Unión Cantinil","Petatán"],
  "Izabal": ["Puerto Barrios","Livingston","El Estor","Morales","Los Amates"],
  "Jalapa": ["Jalapa","San Pedro Pinula","San Luis Jilotepeque","San Manuel Chaparrón","San Carlos Alzatate","Monjas","Mataquescuintla"],
  "Jutiapa": ["Jutiapa","El Progreso","Santa Catarina Mita","Agua Blanca","Asunción Mita","Yupiltepeque","Atescatempa","Jerez","El Adelanto","Zapotitlán","Comapa","Jalpatagua","Conguaco","Moyuta","Pasaco","San José Acatempa","Quezada"],
  "Petén": ["Flores","San José","San Benito","San Andrés","La Libertad","San Francisco","Santa Ana","Dolores","San Luis","Sayaxché","Melchor de Mencos","Poptún","Las Cruces","El Chal"],
  "Quetzaltenango": ["Quetzaltenango","Salcajá","Olintepeque","San Carlos Sija","Sibilia","Cabricán","Cajolá","San Miguel Sigüilá","Ostuncalco","San Mateo","Concepción Chiquirichapa","San Martín Sacatepéquez","Almolonga","Cantel","Huitán","Zunil","Colomba","San Francisco La Unión","El Palmar","Coatepeque","Génova","Flores Costa Cuca","La Esperanza","Palestina de Los Altos"],
  "Quiché": ["Santa Cruz del Quiché","Chiché","Chinique","Zacualpa","Chajul","Chichicastenango","Patzité","San Antonio Ilotenango","San Pedro Jocopilas","Cunén","San Juan Cotzal","Joyabaj","Nebaj","San Andrés Sajcabajá","Uspantán","Sacapulas","San Bartolomé Jocotenango","Canillá","Chicamán","Ixcán","Pachalum"],
  "Retalhuleu": ["Retalhuleu","San Sebastián","Santa Cruz Muluá","San Martín Zapotitlán","San Felipe","San Andrés Villa Seca","Champerico","Nuevo San Carlos","El Asintal"],
  "Sacatepéquez": ["Antigua Guatemala","Jocotenango","Pastores","Sumpango","Santo Domingo Xenacoj","Santiago Sacatepéquez","San Bartolomé Milpas Altas","San Lucas Sacatepéquez","Santa Lucía Milpas Altas","Magdalena Milpas Altas","Santa María de Jesús","Ciudad Vieja","San Miguel Dueñas","Alotenango","San Antonio Aguas Calientes","Santa Catarina Barahona"],
  "San Marcos": ["San Marcos","San Pedro Sacatepéquez","San Antonio Sacatepéquez","Comitancillo","San Miguel Ixtahuacán","Concepción Tutuapa","Tacaná","Sibinal","Tajumulco","Tejutla","San Rafael Pie de la Cuesta","Nuevo Progreso","El Tumbador","El Rodeo","Malacatán","Catarina","Ayutla","Ocós","San Pablo","El Quetzal","La Reforma","Pajapita","Ixchiguán","San José Ojetenam","San Cristóbal Cucho","Sipacapa","Esquipulas Palo Gordo","Río Blanco","San Lorenzo","La Blanca"],
  "Santa Rosa": ["Cuilapa","Barberena","Santa Rosa de Lima","Casillas","San Rafael Las Flores","Oratorio","San Juan Tecuaco","Chiquimulilla","Taxisco","Santa María Ixhuatán","Guazacapán","Santa Cruz Naranjo","Pueblo Nuevo Viñas","Nueva Santa Rosa"],
  "Sololá": ["Sololá","San José Chacayá","Santa María Visitación","Santa Lucía Utatlán","Nahualá","Santa Catarina Ixtahuacán","Santa Clara La Laguna","Concepción","San Andrés Semetabaj","Panajachel","Santa Catarina Palopó","San Antonio Palopó","San Lucas Tolimán","Santa Cruz La Laguna","San Pablo La Laguna","San Marcos La Laguna","San Juan La Laguna","San Pedro La Laguna","Santiago Atitlán"],
  "Suchitepéquez": ["Mazatenango","Cuyotenango","San Francisco Zapotitlán","San Bernardino","San José El Ídolo","Santo Domingo Suchitepéquez","San Lorenzo","Samayac","San Pablo Jocopilas","San Antonio Suchitepéquez","San Miguel Panán","San Gabriel","Chicacao","Patulul","Santa Bárbara","San Juan Bautista","Santo Tomás La Unión","Zunilito","Pueblo Nuevo","Río Bravo"],
  "Totonicapán": ["Totonicapán","San Cristóbal Totonicapán","San Francisco El Alto","San Andrés Xecul","Momostenango","Santa María Chiquimula","Santa Lucía La Reforma","San Bartolo"],
  "Zacapa": ["Zacapa","Estanzuela","Río Hondo","Gualán","Teculután","Usumatlán","Cabañas","San Diego","La Unión","Huité","San Jorge"]
};

export default function MayajStore() {
  const [view, setView] = useState('tienda');
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [sales, setSales] = useState([]);
  const [config, setConfig] = useState({
    apiKeyForza: '', whatsappNumber: '39967739', envioQ: 35,
    recurrenteUrl: 'https://app.recurrente.com/s/mayaj-guatemala/pagar',
    socials: { facebook: '', instagram: '', tiktok: '', whatsapp: '' }
  });
  const [adminLogged, setAdminLogged] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lastOrder, setLastOrder] = useState(null);
  const [shippingData, setShippingData] = useState({
    nombre: '', telefono: '', departamento: '', municipio: '', direccion: '', referencia: ''
  });

  useEffect(() => {
    try {
      const p = storage.get('mayaj:products');
      const s = storage.get('mayaj:sales');
      const c = storage.get('mayaj:config');
      if (p) setProducts(JSON.parse(p.value));
      if (s) setSales(JSON.parse(s.value));
      if (c) setConfig(prev => ({ ...prev, ...JSON.parse(c.value) }));
    } catch (e) { console.log('Primera carga'); }
    finally { setLoading(false); }
  }, []);

  const saveProducts = (n) => { setProducts(n); try { storage.set('mayaj:products', JSON.stringify(n)); } catch(e){} };
  const saveSales = (n) => { setSales(n); try { storage.set('mayaj:sales', JSON.stringify(n)); } catch(e){} };
  const saveConfig = (n) => { setConfig(n); try { storage.set('mayaj:config', JSON.stringify(n)); } catch(e){} };

  const addToCart = (product) => {
    const existing = cart.find(i => i.id === product.id);
    if (existing) setCart(cart.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
    else setCart([...cart, { ...product, qty: 1 }]);
  };
  const updateQty = (id, qty) => {
    if (qty <= 0) setCart(cart.filter(i => i.id !== id));
    else setCart(cart.map(i => i.id === id ? { ...i, qty } : i));
  };
  const removeFromCart = (id) => setCart(cart.filter(i => i.id !== id));
  const cartTotal = cart.reduce((s, i) => s + i.precio * i.qty, 0);

  const finalizarCompra = async (metodoPago) => {
    const total = cartTotal + config.envioQ;
    const order = {
      id: 'ORD-' + Date.now(),
      fecha: new Date().toISOString(),
      cliente: shippingData, productos: cart,
      subtotal: cartTotal, envio: config.envioQ, total, metodoPago,
      estado: metodoPago === 'tarjeta' ? 'Pagado - Por enviar' : 'Pendiente pago - Por enviar',
      guiaForza: null
    };
    if (config.apiKeyForza) {
      try { order.guiaForza = await crearGuiaForza(order); } catch (e) {}
    }
    saveSales([order, ...sales]);
    setLastOrder(order);
    enviarWhatsApp(order);
    setCart([]);
    setView('exito');
  };

  const crearGuiaForza = async (order) => {
    const payload = {
      tipo: 'manual', municipio: order.cliente.municipio, departamento: order.cliente.departamento,
      libras: 10, tipoServicio: order.metodoPago === 'contraentrega' ? 'COD' : 'estandar',
      contacto: { nombre: order.cliente.nombre, telefono: order.cliente.telefono, direccion: order.cliente.direccion, indicaciones: 'Llamar 1 hora antes' },
      montoCobrar: order.metodoPago === 'contraentrega' ? order.total : 0
    };
    try {
      const res = await fetch('https://portal.forzadelivery.com/api/guias/crear', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${config.apiKeyForza}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Error API');
      return await res.json();
    } catch (e) {
      return { error: 'Requiere endpoint oficial de Forza', payload };
    }
  };

  const enviarWhatsApp = (order) => {
    const msg = `*¡Gracias por su compra en Mayaj Guatemala!* 🌸%0A%0A*Orden:* ${order.id}%0A*Cliente:* ${order.cliente.nombre}%0A%0A*Productos:*%0A` +
      order.productos.map(p => `- ${p.nombre} (${p.tamano}) x${p.qty} - Q${(p.precio * p.qty).toFixed(2)}`).join('%0A') +
      `%0A%0A*Subtotal:* Q${order.subtotal.toFixed(2)}%0A*Envío:* Q${order.envio.toFixed(2)}%0A*Total:* Q${order.total.toFixed(2)}%0A%0A*Método:* ${order.metodoPago === 'tarjeta' ? 'Tarjeta (Pagado)' : 'Contra entrega'}%0A*Dirección:* ${order.cliente.direccion}, ${order.cliente.municipio}, ${order.cliente.departamento}` +
      (order.guiaForza && !order.guiaForza.error ? `%0A*Guía Forza:* ${order.guiaForza.numeroGuia || 'Generada'}` : '');
    window.open(`https://wa.me/502${order.cliente.telefono}?text=${msg}`, '_blank');
    setTimeout(() => window.open(`https://wa.me/502${config.whatsappNumber}?text=${msg}`, '_blank'), 500);
  };

  if (loading) return (
    <div style={{ background: '#fff', minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div className="spinner" /><p style={{ color: '#e91e63', fontFamily: "'Playfair Display', serif", fontSize: '1.5rem', marginTop: '1rem' }}>Mayaj</p>
      </div>
    </div>
  );

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh', fontFamily: 'var(--body)' }}>
      <GlobalStyles />
      <Header view={view} setView={setView} cartCount={cart.reduce((s, i) => s + i.qty, 0)} />
      {view === 'tienda' && <TiendaView products={products} addToCart={addToCart} />}
      {view === 'carrito' && <CarritoView cart={cart} updateQty={updateQty} removeFromCart={removeFromCart} total={cartTotal} setView={setView} />}
      {view === 'envio' && <EnvioView shippingData={shippingData} setShippingData={setShippingData} setView={setView} />}
      {view === 'pago' && <PagoView total={cartTotal} envio={config.envioQ} recurrenteUrl={config.recurrenteUrl} finalizarCompra={finalizarCompra} setView={setView} />}
      {view === 'exito' && <ExitoView order={lastOrder} setView={setView} />}
      {view === 'admin' && (adminLogged ? <AdminPanel products={products} saveProducts={saveProducts} sales={sales} saveSales={saveSales} config={config} saveConfig={saveConfig} setAdminLogged={setAdminLogged} /> : <AdminLogin setAdminLogged={setAdminLogged} />)}
      <Footer socials={config.socials} />
    </div>
  );
}

function GlobalStyles() {
  return (<style>{`
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&display=swap');
    :root { --bg:#fff; --bg-soft:#fff5f8; --rose:#e91e63; --rose-light:#f8bbd0; --rose-dark:#ad1457; --black:#1a1a1a; --gray:#666; --gray-light:#eee; --display:'Playfair Display','Georgia',serif; --body:'Poppins',-apple-system,sans-serif; }
    *{box-sizing:border-box} body{margin:0;background:#fff;font-family:'Poppins',sans-serif}
    .btn-primary{background:var(--rose);color:#fff;border:none;padding:.85rem 1.75rem;font-family:var(--body);font-weight:600;font-size:.95rem;border-radius:999px;cursor:pointer;transition:all .3s;letter-spacing:.03em}
    .btn-primary:hover{background:var(--rose-dark);transform:translateY(-2px);box-shadow:0 8px 20px rgba(233,30,99,.3)}
    .btn-primary:disabled{background:var(--gray-light);color:var(--gray);cursor:not-allowed;transform:none;box-shadow:none}
    .btn-secondary{background:transparent;color:var(--black);border:2px solid var(--black);padding:.75rem 1.5rem;font-family:var(--body);font-weight:600;border-radius:999px;cursor:pointer;transition:all .3s}
    .btn-secondary:hover{background:var(--black);color:#fff}
    .input,.select,.textarea{width:100%;padding:.85rem 1rem;border:1.5px solid var(--gray-light);border-radius:12px;font-family:var(--body);font-size:.95rem;background:#fff;transition:border-color .2s}
    .input:focus,.select:focus,.textarea:focus{outline:none;border-color:var(--rose)}
    .label{display:block;font-size:.8rem;font-weight:600;color:var(--black);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.4rem}
    .spinner{width:48px;height:48px;border:4px solid var(--rose-light);border-top-color:var(--rose);border-radius:50%;animation:spin .8s linear infinite;margin:0 auto}
    @keyframes spin{to{transform:rotate(360deg)}}
    @keyframes fadeUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
    .fade-up{animation:fadeUp .5s ease-out}
    .card{background:#fff;border-radius:20px;overflow:hidden;transition:all .3s;border:1px solid var(--gray-light)}
    .card:hover{transform:translateY(-4px);box-shadow:0 20px 40px rgba(0,0,0,.08)}
  `}</style>);
}

function Header({ view, setView, cartCount }) {
  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 100, background: 'rgba(255,255,255,.95)', backdropFilter: 'blur(20px)', borderBottom: '1px solid var(--gray-light)', padding: '1rem 0' }}>
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '0 1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ cursor: 'pointer' }} onClick={() => setView('tienda')}>
          <div style={{ fontFamily: 'var(--display)', fontSize: '1.8rem', fontWeight: 900, color: 'var(--black)', lineHeight: 1, letterSpacing: '-.02em' }}>Mayaj</div>
          <div style={{ fontSize: '.65rem', color: 'var(--rose)', letterSpacing: '.3em', textTransform: 'uppercase', marginTop: 2 }}>Guatemala</div>
        </div>
        <nav style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button onClick={() => setView('tienda')} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--body)', fontSize: '.9rem', fontWeight: view === 'tienda' ? 600 : 400, color: view === 'tienda' ? 'var(--rose)' : 'var(--black)' }}>Tienda</button>
          <button onClick={() => setView('admin')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: view === 'admin' ? 'var(--rose)' : 'var(--gray)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <Settings size={16} /> <span style={{ fontSize: '.85rem' }}>Admin</span>
          </button>
          <button onClick={() => setView('carrito')} style={{ position: 'relative', background: 'var(--black)', color: '#fff', border: 'none', width: 44, height: 44, borderRadius: '50%', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <ShoppingBag size={18} />
            {cartCount > 0 && <span style={{ position: 'absolute', top: -4, right: -4, background: 'var(--rose)', color: '#fff', fontSize: '.7rem', fontWeight: 700, minWidth: 20, height: 20, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 4px' }}>{cartCount}</span>}
          </button>
        </nav>
      </div>
    </header>
  );
}

function TiendaView({ products, addToCart }) {
  const [filter, setFilter] = useState('todos');
  const tamanos = ['Vara y media', '2 varas', '2 varas y media'];
  const filtered = filter === 'todos' ? products : products.filter(p => p.tamano === filter);

  return (
    <main className="fade-up" style={{ maxWidth: 1280, margin: '0 auto', padding: '3rem 1.5rem' }}>
      <section style={{ textAlign: 'center', marginBottom: '4rem', padding: '3rem 1rem', background: 'linear-gradient(135deg,var(--bg-soft) 0%,#fff 100%)', borderRadius: 32, border: '1px solid var(--rose-light)' }}>
        <div style={{ fontSize: '.75rem', color: 'var(--rose)', letterSpacing: '.4em', textTransform: 'uppercase', marginBottom: '1rem' }}>Perrajes Artesanales</div>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: 'clamp(2.5rem,6vw,4.5rem)', fontWeight: 900, color: 'var(--black)', lineHeight: 1.05, margin: '0 0 1rem', letterSpacing: '-.02em' }}>
          Tradición tejida <em style={{ color: 'var(--rose)', fontStyle: 'italic' }}>a mano</em>
        </h1>
        <p style={{ fontSize: '1.05rem', color: 'var(--gray)', maxWidth: 600, margin: '0 auto' }}>Perrajes auténticos de Guatemala. Elige tu tamaño ideal.</p>
      </section>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '.75rem', justifyContent: 'center', marginBottom: '3rem' }}>
        <button onClick={() => setFilter('todos')} className={filter === 'todos' ? 'btn-primary' : 'btn-secondary'}>Todos</button>
        {tamanos.map(t => <button key={t} onClick={() => setFilter(t)} className={filter === t ? 'btn-primary' : 'btn-secondary'}>{t}</button>)}
      </div>

      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem 1rem', color: 'var(--gray)' }}>
          <Package size={48} style={{ opacity: .3, marginBottom: '1rem' }} />
          <p>{products.length === 0 ? 'Aún no hay productos. El administrador puede agregarlos desde el panel.' : 'No hay productos en esta categoría.'}</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(260px,1fr))', gap: '1.5rem' }}>
          {filtered.map(p => <ProductCard key={p.id} product={p} onAdd={() => addToCart(p)} />)}
        </div>
      )}
    </main>
  );
}

function ProductCard({ product, onAdd }) {
  return (
    <article className="card fade-up">
      <div style={{ aspectRatio: '4/5', background: 'var(--bg-soft)', overflow: 'hidden', position: 'relative' }}>
        {product.imagen ? <img src={product.imagen} alt={product.nombre} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> :
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--rose-light)' }}><Package size={64} /></div>}
        <div style={{ position: 'absolute', top: 12, left: 12, background: 'var(--black)', color: '#fff', padding: '4px 12px', borderRadius: 999, fontSize: '.7rem', fontWeight: 600, letterSpacing: '.05em' }}>{product.tamano}</div>
      </div>
      <div style={{ padding: '1.25rem' }}>
        <h3 style={{ fontFamily: 'var(--display)', fontSize: '1.2rem', margin: '0 0 .5rem', color: 'var(--black)', fontWeight: 700 }}>{product.nombre}</h3>
        <p style={{ fontSize: '.85rem', color: 'var(--gray)', margin: '0 0 1rem', minHeight: '2.5em', lineHeight: 1.5 }}>{product.descripcion}</p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontFamily: 'var(--display)', fontSize: '1.5rem', fontWeight: 700, color: 'var(--rose)' }}>Q{product.precio.toFixed(2)}</div>
          <button onClick={onAdd} className="btn-primary" style={{ padding: '.6rem 1rem', fontSize: '.85rem' }}>
            <Plus size={16} style={{ verticalAlign: 'middle', marginRight: 4 }} /> Agregar
          </button>
        </div>
      </div>
    </article>
  );
}

function CarritoView({ cart, updateQty, removeFromCart, total, setView }) {
  return (
    <main className="fade-up" style={{ maxWidth: 900, margin: '0 auto', padding: '3rem 1.5rem' }}>
      <h1 style={{ fontFamily: 'var(--display)', fontSize: '2.5rem', fontWeight: 900, margin: '0 0 2rem' }}>Tu carrito</h1>
      {cart.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem 1rem', background: 'var(--bg-soft)', borderRadius: 20 }}>
          <ShoppingBag size={48} style={{ color: 'var(--rose-light)', marginBottom: '1rem' }} />
          <p style={{ color: 'var(--gray)', marginBottom: '1.5rem' }}>Tu carrito está vacío</p>
          <button onClick={() => setView('tienda')} className="btn-primary">Explorar productos</button>
        </div>
      ) : (<>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '2rem' }}>
          {cart.map(item => (
            <div key={item.id} className="card" style={{ padding: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
              <div style={{ width: 80, height: 80, background: 'var(--bg-soft)', borderRadius: 12, overflow: 'hidden', flexShrink: 0 }}>
                {item.imagen ? <img src={item.imagen} alt={item.nombre} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> :
                  <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--rose-light)' }}><Package size={30} /></div>}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600 }}>{item.nombre}</div>
                <div style={{ fontSize: '.8rem', color: 'var(--gray)' }}>{item.tamano}</div>
                <div style={{ color: 'var(--rose)', fontWeight: 700, marginTop: 4 }}>Q{item.precio.toFixed(2)}</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '.5rem' }}>
                <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ width: 32, height: 32, border: '1px solid var(--gray-light)', background: '#fff', borderRadius: 8, cursor: 'pointer', fontSize: '1.2rem' }}>−</button>
                <span style={{ minWidth: 24, textAlign: 'center', fontWeight: 600 }}>{item.qty}</span>
                <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ width: 32, height: 32, border: '1px solid var(--gray-light)', background: '#fff', borderRadius: 8, cursor: 'pointer', fontSize: '1.2rem' }}>+</button>
              </div>
              <button onClick={() => removeFromCart(item.id)} style={{ background: 'none', border: 'none', color: 'var(--gray)', cursor: 'pointer', padding: 8 }}><Trash2 size={18} /></button>
            </div>
          ))}
        </div>
        <div style={{ background: 'var(--bg-soft)', padding: '1.5rem', borderRadius: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <div>
            <div style={{ fontSize: '.8rem', color: 'var(--gray)', textTransform: 'uppercase', letterSpacing: '.1em' }}>Subtotal</div>
            <div style={{ fontFamily: 'var(--display)', fontSize: '2rem', fontWeight: 900 }}>Q{total.toFixed(2)}</div>
            <div style={{ fontSize: '.8rem', color: 'var(--gray)' }}>Envío se suma en el siguiente paso</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <button onClick={() => setView('tienda')} className="btn-secondary"><ArrowLeft size={16} style={{ verticalAlign: 'middle', marginRight: 4 }} /> Seguir comprando</button>
          <button onClick={() => setView('envio')} className="btn-primary" style={{ flex: 1 }}>Continuar al envío →</button>
        </div>
      </>)}
    </main>
  );
}

function EnvioView({ shippingData, setShippingData, setView }) {
  const [errors, setErrors] = useState({});
  const municipios = shippingData.departamento ? DEPARTAMENTOS_GT[shippingData.departamento] || [] : [];
  const validar = () => {
    const e = {};
    if (!shippingData.nombre.trim()) e.nombre = 'Requerido';
    if (!shippingData.telefono.trim() || shippingData.telefono.length < 8) e.telefono = 'Teléfono de 8 dígitos';
    if (!shippingData.departamento) e.departamento = 'Requerido';
    if (!shippingData.municipio) e.municipio = 'Requerido';
    if (!shippingData.direccion.trim()) e.direccion = 'Requerido';
    setErrors(e); return Object.keys(e).length === 0;
  };
  const handleNext = () => { if (validar()) setView('pago'); };
  const update = (field, value) => {
    const n = { ...shippingData, [field]: value };
    if (field === 'departamento') n.municipio = '';
    setShippingData(n);
  };

  return (
    <main className="fade-up" style={{ maxWidth: 700, margin: '0 auto', padding: '3rem 1.5rem' }}>
      <button onClick={() => setView('carrito')} style={{ background: 'none', border: 'none', color: 'var(--gray)', cursor: 'pointer', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: 4 }}>
        <ArrowLeft size={16} /> Volver al carrito
      </button>
      <h1 style={{ fontFamily: 'var(--display)', fontSize: '2.2rem', fontWeight: 900, margin: '0 0 .5rem' }}>Dirección de envío</h1>
      <p style={{ color: 'var(--gray)', marginBottom: '2rem' }}>Completa los datos para el envío de tu pedido.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        <div>
          <label className="label">Nombre de quien recibe</label>
          <input className="input" value={shippingData.nombre} onChange={e => update('nombre', e.target.value)} placeholder="Ej. María López" />
          {errors.nombre && <small style={{ color: 'var(--rose)' }}>{errors.nombre}</small>}
        </div>
        <div>
          <label className="label">Número de teléfono</label>
          <input className="input" type="tel" maxLength={8} value={shippingData.telefono} onChange={e => update('telefono', e.target.value.replace(/\D/g, ''))} placeholder="Ej. 55551234" />
          {errors.telefono && <small style={{ color: 'var(--rose)' }}>{errors.telefono}</small>}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <div>
            <label className="label">Departamento</label>
            <select className="select" value={shippingData.departamento} onChange={e => update('departamento', e.target.value)}>
              <option value="">Selecciona...</option>
              {Object.keys(DEPARTAMENTOS_GT).sort().map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            {errors.departamento && <small style={{ color: 'var(--rose)' }}>{errors.departamento}</small>}
          </div>
          <div>
            <label className="label">Municipio</label>
            <select className="select" value={shippingData.municipio} onChange={e => update('municipio', e.target.value)} disabled={!shippingData.departamento}>
              <option value="">Selecciona...</option>
              {municipios.sort().map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            {errors.municipio && <small style={{ color: 'var(--rose)' }}>{errors.municipio}</small>}
          </div>
        </div>
        <div>
          <label className="label">Dirección exacta</label>
          <input className="input" value={shippingData.direccion} onChange={e => update('direccion', e.target.value)} placeholder="Ej. 5a calle 3-45 zona 1" />
          {errors.direccion && <small style={{ color: 'var(--rose)' }}>{errors.direccion}</small>}
        </div>
        <div>
          <label className="label">Referencia (opcional)</label>
          <textarea className="textarea" rows={3} value={shippingData.referencia} onChange={e => update('referencia', e.target.value)} placeholder="Ej. Casa color blanco, portón negro" />
        </div>
        <button onClick={handleNext} className="btn-primary" style={{ marginTop: '1rem' }}>Continuar al pago →</button>
      </div>
    </main>
  );
}

function PagoView({ total, envio, recurrenteUrl, finalizarCompra, setView }) {
  const [metodo, setMetodo] = useState(null);
  const totalFinal = total + envio;
  return (
    <main className="fade-up" style={{ maxWidth: 700, margin: '0 auto', padding: '3rem 1.5rem' }}>
      <button onClick={() => setView('envio')} style={{ background: 'none', border: 'none', color: 'var(--gray)', cursor: 'pointer', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: 4 }}>
        <ArrowLeft size={16} /> Volver
      </button>
      <h1 style={{ fontFamily: 'var(--display)', fontSize: '2.2rem', fontWeight: 900, margin: '0 0 .5rem' }}>Método de pago</h1>
      <div style={{ background: 'var(--bg-soft)', padding: '1.25rem', borderRadius: 16, marginBottom: '2rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', color: 'var(--gray)' }}><span>Subtotal</span><span>Q{total.toFixed(2)}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.9rem', color: 'var(--gray)' }}><span>Envío</span><span>Q{envio.toFixed(2)}</span></div>
        <hr style={{ border: 'none', borderTop: '1px dashed var(--gray-light)', margin: '.75rem 0' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1.25rem' }}><span>Total</span><span style={{ color: 'var(--rose)' }}>Q{totalFinal.toFixed(2)}</span></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <button onClick={() => setMetodo('tarjeta')} style={{ padding: '1.5rem', border: `2px solid ${metodo === 'tarjeta' ? 'var(--rose)' : 'var(--gray-light)'}`, borderRadius: 16, background: metodo === 'tarjeta' ? 'var(--bg-soft)' : '#fff', cursor: 'pointer', textAlign: 'left', transition: 'all .3s' }}>
          <CreditCard size={28} style={{ color: 'var(--rose)', marginBottom: '.5rem' }} />
          <div style={{ fontWeight: 700, marginBottom: 4 }}>Pago con tarjeta</div>
          <div style={{ fontSize: '.85rem', color: 'var(--gray)' }}>Pagas ahora con Recurrente.</div>
        </button>
        <button onClick={() => setMetodo('contraentrega')} style={{ padding: '1.5rem', border: `2px solid ${metodo === 'contraentrega' ? 'var(--rose)' : 'var(--gray-light)'}`, borderRadius: 16, background: metodo === 'contraentrega' ? 'var(--bg-soft)' : '#fff', cursor: 'pointer', textAlign: 'left', transition: 'all .3s' }}>
          <Truck size={28} style={{ color: 'var(--rose)', marginBottom: '.5rem' }} />
          <div style={{ fontWeight: 700, marginBottom: 4 }}>Pago contra entrega</div>
          <div style={{ fontSize: '.85rem', color: 'var(--gray)' }}>Pagas al recibir.</div>
        </button>
      </div>
      {metodo === 'tarjeta' && (
        <div style={{ padding: '1.25rem', background: '#fff9fc', border: '1px solid var(--rose-light)', borderRadius: 16, marginBottom: '1.5rem' }}>
          <p style={{ margin: '0 0 1rem', fontSize: '.9rem' }}>Se abrirá Recurrente con el monto de <strong>Q{totalFinal.toFixed(2)}</strong>. Después confirma tu compra aquí.</p>
          <a href={`${recurrenteUrl}?amount=${totalFinal.toFixed(2)}&locked=true`} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ display: 'inline-block', textDecoration: 'none' }}>
            Pagar Q{totalFinal.toFixed(2)} en Recurrente →
          </a>
        </div>
      )}
      <button onClick={() => finalizarCompra(metodo)} disabled={!metodo} className="btn-primary" style={{ width: '100%', padding: '1rem' }}>
        {metodo === 'tarjeta' ? 'Ya pagué, confirmar compra' : metodo === 'contraentrega' ? `Confirmar (pago al recibir Q${totalFinal.toFixed(2)})` : 'Selecciona un método'}
      </button>
    </main>
  );
}

function ExitoView({ order, setView }) {
  if (!order) return null;
  return (
    <main className="fade-up" style={{ maxWidth: 700, margin: '0 auto', padding: '3rem 1.5rem', textAlign: 'center' }}>
      <div style={{ width: 90, height: 90, borderRadius: '50%', background: 'var(--rose)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.5rem' }}>
        <Check size={48} color="#fff" />
      </div>
      <h1 style={{ fontFamily: 'var(--display)', fontSize: '2.5rem', fontWeight: 900, margin: '0 0 .5rem' }}>¡Su compra ha sido exitosa!</h1>
      <p style={{ color: 'var(--gray)', fontSize: '1.05rem' }}>Orden <strong style={{ color: 'var(--black)' }}>{order.id}</strong></p>
      <div style={{ background: 'var(--bg-soft)', padding: '1.5rem', borderRadius: 20, margin: '2rem 0', textAlign: 'left' }}>
        <h3 style={{ fontFamily: 'var(--display)', margin: '0 0 1rem' }}>Resumen</h3>
        {order.productos.map(p => (
          <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '.5rem 0', borderBottom: '1px dashed var(--gray-light)' }}>
            <span>{p.nombre} × {p.qty}</span><span>Q{(p.precio * p.qty).toFixed(2)}</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '.5rem 0', color: 'var(--gray)' }}><span>Envío</span><span>Q{order.envio.toFixed(2)}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '.75rem 0 0', fontWeight: 700, fontSize: '1.2rem' }}><span>Total</span><span style={{ color: 'var(--rose)' }}>Q{order.total.toFixed(2)}</span></div>
      </div>
      <p style={{ color: 'var(--gray)', fontSize: '.9rem', marginBottom: '1.5rem' }}>Te enviaremos un mensaje por WhatsApp con los detalles.</p>
      <button onClick={() => setView('tienda')} className="btn-primary">Volver a la tienda</button>
    </main>
  );
}

function AdminLogin({ setAdminLogged }) {
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');
  const handleLogin = () => { if (pass === 'mayaj2026') setAdminLogged(true); else setErr('Contraseña incorrecta'); };
  return (
    <main className="fade-up" style={{ maxWidth: 400, margin: '4rem auto', padding: '2.5rem', background: '#fff', borderRadius: 20, border: '1px solid var(--gray-light)' }}>
      <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{ width: 60, height: 60, background: 'var(--rose)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
          <Lock size={24} color="#fff" />
        </div>
        <h2 style={{ fontFamily: 'var(--display)', margin: 0 }}>Panel de administración</h2>
      </div>
      <input className="input" type="password" value={pass} onChange={e => { setPass(e.target.value); setErr(''); }} placeholder="Contraseña" onKeyDown={e => e.key === 'Enter' && handleLogin()} />
      {err && <small style={{ color: 'var(--rose)' }}>{err}</small>}
      <button onClick={handleLogin} className="btn-primary" style={{ width: '100%', marginTop: '1rem' }}>Entrar</button>
      <p style={{ fontSize: '.75rem', color: 'var(--gray)', marginTop: '1rem', textAlign: 'center' }}>Por defecto: <code>mayaj2026</code></p>
    </main>
  );
}

function AdminPanel({ products, saveProducts, sales, saveSales, config, saveConfig, setAdminLogged }) {
  const [tab, setTab] = useState('productos');
  return (
    <main className="fade-up" style={{ maxWidth: 1280, margin: '0 auto', padding: '2rem 1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <h1 style={{ fontFamily: 'var(--display)', fontSize: '2rem', fontWeight: 900, margin: 0 }}>Panel de administración</h1>
        <button onClick={() => setAdminLogged(false)} className="btn-secondary">Cerrar sesión</button>
      </div>
      <div style={{ display: 'flex', gap: '.5rem', marginBottom: '2rem', borderBottom: '1px solid var(--gray-light)', flexWrap: 'wrap' }}>
        {[{ id: 'productos', label: 'Productos', icon: Package }, { id: 'ventas', label: 'Ventas', icon: TrendingUp }, { id: 'config', label: 'Configuración', icon: Settings }].map(t => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: '.75rem 1.25rem', background: 'none', border: 'none', borderBottom: `3px solid ${tab === t.id ? 'var(--rose)' : 'transparent'}`, color: tab === t.id ? 'var(--rose)' : 'var(--gray)', cursor: 'pointer', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon size={16} /> {t.label}
            </button>
          );
        })}
      </div>
      {tab === 'productos' && <AdminProducts products={products} saveProducts={saveProducts} />}
      {tab === 'ventas' && <AdminSales sales={sales} saveSales={saveSales} />}
      {tab === 'config' && <AdminConfig config={config} saveConfig={saveConfig} />}
    </main>
  );
}

function AdminProducts({ products, saveProducts }) {
  const [editing, setEditing] = useState(null);
  const tamanos = ['Vara y media', '2 varas', '2 varas y media'];
  const emptyProduct = { id: '', nombre: '', descripcion: '', precio: '', tamano: tamanos[0], imagen: '' };

  const handleSave = (prod) => {
    if (!prod.nombre || !prod.precio || !prod.tamano) return alert('Nombre, precio y tamaño son requeridos');
    const newProd = { ...prod, precio: parseFloat(prod.precio), id: prod.id || 'P-' + Date.now() };
    if (prod.id) saveProducts(products.map(p => p.id === prod.id ? newProd : p));
    else saveProducts([...products, newProd]);
    setEditing(null);
  };
  const handleDelete = (id) => { if (confirm('¿Eliminar producto?')) saveProducts(products.filter(p => p.id !== id)); };
  const handleImageUpload = (e, prod) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return alert('Máximo 2MB.');
    const reader = new FileReader();
    reader.onload = ev => setEditing({ ...prod, imagen: ev.target.result });
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ fontSize: '.8rem', color: 'var(--gray)', textTransform: 'uppercase', letterSpacing: '.1em' }}>Total productos</div>
          <div style={{ fontFamily: 'var(--display)', fontSize: '2rem', fontWeight: 700 }}>{products.length}</div>
        </div>
        <button onClick={() => setEditing(emptyProduct)} className="btn-primary"><Plus size={16} style={{ verticalAlign: 'middle', marginRight: 4 }} /> Nuevo producto</button>
      </div>
      {editing && (
        <div style={{ background: 'var(--bg-soft)', padding: '1.5rem', borderRadius: 20, marginBottom: '1.5rem' }}>
          <h3 style={{ fontFamily: 'var(--display)', margin: '0 0 1rem' }}>{editing.id ? 'Editar' : 'Nuevo'} producto</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '1rem', marginBottom: '1rem' }}>
            <div><label className="label">Nombre</label><input className="input" value={editing.nombre} onChange={e => setEditing({ ...editing, nombre: e.target.value })} /></div>
            <div><label className="label">Tamaño</label><select className="select" value={editing.tamano} onChange={e => setEditing({ ...editing, tamano: e.target.value })}>{tamanos.map(t => <option key={t}>{t}</option>)}</select></div>
            <div><label className="label">Precio (Q)</label><input className="input" type="number" step="0.01" value={editing.precio} onChange={e => setEditing({ ...editing, precio: e.target.value })} /></div>
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label className="label">Descripción</label>
            <textarea className="textarea" rows={3} value={editing.descripcion} onChange={e => setEditing({ ...editing, descripcion: e.target.value })} />
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label className="label">Imagen</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
              {editing.imagen && <img src={editing.imagen} alt="preview" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 12 }} />}
              <label className="btn-secondary" style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                <Upload size={16} /> Subir imagen
                <input type="file" accept="image/*" onChange={e => handleImageUpload(e, editing)} style={{ display: 'none' }} />
              </label>
              {editing.imagen && <button onClick={() => setEditing({ ...editing, imagen: '' })} className="btn-secondary">Quitar</button>}
            </div>
          </div>
          <div style={{ display: 'flex', gap: '.5rem' }}>
            <button onClick={() => handleSave(editing)} className="btn-primary">Guardar</button>
            <button onClick={() => setEditing(null)} className="btn-secondary">Cancelar</button>
          </div>
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(240px,1fr))', gap: '1rem' }}>
        {products.map(p => (
          <div key={p.id} className="card" style={{ padding: '1rem' }}>
            <div style={{ aspectRatio: '1', background: 'var(--bg-soft)', borderRadius: 12, overflow: 'hidden', marginBottom: '.75rem' }}>
              {p.imagen ? <img src={p.imagen} alt={p.nombre} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> :
                <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--rose-light)' }}><Package size={48} /></div>}
            </div>
            <div style={{ fontWeight: 600 }}>{p.nombre}</div>
            <div style={{ fontSize: '.75rem', color: 'var(--gray)' }}>{p.tamano}</div>
            <div style={{ color: 'var(--rose)', fontWeight: 700, margin: '.25rem 0 .5rem' }}>Q{p.precio.toFixed(2)}</div>
            <div style={{ display: 'flex', gap: '.5rem' }}>
              <button onClick={() => setEditing(p)} style={{ flex: 1, padding: '.4rem', border: '1px solid var(--gray-light)', background: '#fff', borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, fontSize: '.8rem' }}><Edit3 size={14} /> Editar</button>
              <button onClick={() => handleDelete(p.id)} style={{ padding: '.4rem .6rem', border: '1px solid var(--gray-light)', background: '#fff', borderRadius: 8, cursor: 'pointer', color: 'var(--rose)' }}><Trash2 size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminSales({ sales, saveSales }) {
  const [filter, setFilter] = useState('todas');
  const [expanded, setExpanded] = useState(null);
  const filtered = filter === 'todas' ? sales : sales.filter(s => s.estado.toLowerCase().includes(filter));
  const totalVentas = sales.reduce((sum, s) => sum + s.total, 0);
  const totalUnidades = sales.reduce((sum, s) => sum + s.productos.reduce((ss, p) => ss + p.qty, 0), 0);
  const updateEstado = (id, n) => saveSales(sales.map(s => s.id === id ? { ...s, estado: n } : s));
  const eliminarVenta = (id) => { if (confirm('¿Eliminar?')) saveSales(sales.filter(s => s.id !== id)); };

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
        <StatCard label="Total ventas" value={`Q${totalVentas.toFixed(2)}`} />
        <StatCard label="# Órdenes" value={sales.length} />
        <StatCard label="Unidades" value={totalUnidades} />
        <StatCard label="Pendientes" value={sales.filter(s => s.estado.includes('Pendiente') || s.estado.includes('Por enviar')).length} />
      </div>
      <div style={{ display: 'flex', gap: '.5rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
        {['todas', 'pendiente', 'pagado', 'enviado', 'entregado'].map(f => (
          <button key={f} onClick={() => setFilter(f)} className={filter === f ? 'btn-primary' : 'btn-secondary'} style={{ fontSize: '.8rem', padding: '.5rem 1rem' }}>{f.charAt(0).toUpperCase() + f.slice(1)}</button>
        ))}
      </div>
      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem 1rem', color: 'var(--gray)' }}>
          <TrendingUp size={48} style={{ opacity: .3, marginBottom: '1rem' }} />
          <p>No hay ventas registradas.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '.75rem' }}>
          {filtered.map(s => (
            <div key={s.id} className="card" style={{ padding: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
                <div style={{ flex: 1, minWidth: 200 }}>
                  <div style={{ display: 'flex', gap: '.5rem', alignItems: 'center', marginBottom: '.25rem' }}>
                    <strong>{s.id}</strong>
                    <span style={{ fontSize: '.7rem', padding: '2px 8px', background: s.metodoPago === 'tarjeta' ? '#e3f2fd' : '#fff3e0', borderRadius: 999, fontWeight: 600 }}>{s.metodoPago === 'tarjeta' ? '💳 Tarjeta' : '📦 Contra entrega'}</span>
                  </div>
                  <div style={{ fontSize: '.85rem', color: 'var(--gray)' }}>{new Date(s.fecha).toLocaleString('es-GT')}</div>
                  <div style={{ fontWeight: 600, marginTop: '.25rem' }}>{s.cliente.nombre}</div>
                  <div style={{ fontSize: '.85rem', color: 'var(--gray)' }}>Tel: {s.cliente.telefono} · {s.cliente.municipio}, {s.cliente.departamento}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '.7rem', color: 'var(--gray)', textTransform: 'uppercase' }}>Total</div>
                  <div style={{ fontFamily: 'var(--display)', fontSize: '1.5rem', fontWeight: 700, color: 'var(--rose)' }}>Q{s.total.toFixed(2)}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '.5rem', marginTop: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
                <select className="select" style={{ width: 'auto', padding: '.4rem .75rem', fontSize: '.85rem' }} value={s.estado} onChange={e => updateEstado(s.id, e.target.value)}>
                  <option>Pendiente pago - Por enviar</option><option>Pagado - Por enviar</option>
                  <option>En camino</option><option>Entregado</option><option>Cancelado</option>
                </select>
                <button onClick={() => setExpanded(expanded === s.id ? null : s.id)} className="btn-secondary" style={{ fontSize: '.8rem', padding: '.4rem .9rem' }}>
                  {expanded === s.id ? <><EyeOff size={14} /> Ocultar</> : <><Eye size={14} /> Detalle</>}
                </button>
                <a href={`https://wa.me/502${s.cliente.telefono}`} target="_blank" rel="noopener noreferrer" className="btn-secondary" style={{ fontSize: '.8rem', padding: '.4rem .9rem', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                  <MessageCircle size={14} /> WhatsApp
                </a>
                <button onClick={() => eliminarVenta(s.id)} className="btn-secondary" style={{ fontSize: '.8rem', padding: '.4rem .9rem', color: 'var(--rose)', borderColor: 'var(--rose-light)' }}><Trash2 size={14} /></button>
              </div>
              {expanded === s.id && (
                <div style={{ marginTop: '1rem', padding: '1rem', background: 'var(--bg-soft)', borderRadius: 12 }}>
                  <strong style={{ fontSize: '.85rem' }}>Productos:</strong>
                  {s.productos.map(p => (
                    <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.85rem', padding: '.25rem 0' }}>
                      <span>{p.nombre} ({p.tamano}) × {p.qty}</span><span>Q{(p.precio * p.qty).toFixed(2)}</span>
                    </div>
                  ))}
                  <div style={{ fontSize: '.85rem', marginTop: '.5rem', paddingTop: '.5rem', borderTop: '1px dashed var(--gray-light)' }}>
                    <div><strong>Dirección:</strong> {s.cliente.direccion}</div>
                    {s.cliente.referencia && <div><strong>Referencia:</strong> {s.cliente.referencia}</div>}
                    <div><strong>Subtotal:</strong> Q{s.subtotal.toFixed(2)} · <strong>Envío:</strong> Q{s.envio.toFixed(2)}</div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div style={{ padding: '1.25rem', background: '#fff', border: '1px solid var(--gray-light)', borderRadius: 16 }}>
      <div style={{ fontSize: '.75rem', color: 'var(--gray)', textTransform: 'uppercase', letterSpacing: '.1em' }}>{label}</div>
      <div style={{ fontFamily: 'var(--display)', fontSize: '1.75rem', fontWeight: 700, marginTop: '.25rem' }}>{value}</div>
    </div>
  );
}

function AdminConfig({ config, saveConfig }) {
  const [form, setForm] = useState(config);
  const [saved, setSaved] = useState(false);
  const handleSave = () => { saveConfig(form); setSaved(true); setTimeout(() => setSaved(false), 2000); };
  return (
    <div style={{ maxWidth: 700 }}>
      <div style={{ background: '#fff9fc', border: '1px solid var(--rose-light)', padding: '1rem', borderRadius: 12, marginBottom: '1.5rem' }}>
        <h3 style={{ margin: '0 0 .5rem', fontFamily: 'var(--display)' }}>🔑 API Key de Forza Delivery</h3>
        <p style={{ fontSize: '.85rem', color: 'var(--gray)', margin: '0 0 .75rem' }}>
          Cuando agregues tu API key, se creará la guía automáticamente en <a href="https://portal.forzadelivery.com/login-corporate" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--rose)' }}>Forza Delivery</a>.
        </p>
        <input className="input" type="password" placeholder="pk_live_..." value={form.apiKeyForza} onChange={e => setForm({ ...form, apiKeyForza: e.target.value })} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
        <div><label className="label">WhatsApp del negocio</label><input className="input" value={form.whatsappNumber} onChange={e => setForm({ ...form, whatsappNumber: e.target.value })} /></div>
        <div><label className="label">Costo de envío (Q)</label><input className="input" type="number" value={form.envioQ} onChange={e => setForm({ ...form, envioQ: parseFloat(e.target.value) || 0 })} /></div>
        <div><label className="label">URL de Recurrente</label><input className="input" value={form.recurrenteUrl} onChange={e => setForm({ ...form, recurrenteUrl: e.target.value })} /></div>
      </div>
      <h3 style={{ fontFamily: 'var(--display)', marginTop: '2rem' }}>Redes sociales</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
        <SocialInput icon={Facebook} label="Facebook" value={form.socials?.facebook || ''} onChange={v => setForm({ ...form, socials: { ...form.socials, facebook: v } })} />
        <SocialInput icon={Instagram} label="Instagram" value={form.socials?.instagram || ''} onChange={v => setForm({ ...form, socials: { ...form.socials, instagram: v } })} />
        <SocialInput icon={Music2} label="TikTok" value={form.socials?.tiktok || ''} onChange={v => setForm({ ...form, socials: { ...form.socials, tiktok: v } })} />
        <SocialInput icon={MessageCircle} label="WhatsApp (link)" value={form.socials?.whatsapp || ''} onChange={v => setForm({ ...form, socials: { ...form.socials, whatsapp: v } })} />
      </div>
      <button onClick={handleSave} className="btn-primary">{saved ? <><Check size={16} /> Guardado</> : 'Guardar configuración'}</button>
    </div>
  );
}

function SocialInput({ icon: Icon, label, value, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem' }}>
      <div style={{ width: 40, height: 40, background: 'var(--bg-soft)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon size={20} style={{ color: 'var(--rose)' }} />
      </div>
      <div style={{ flex: 1 }}>
        <label className="label" style={{ marginBottom: '.2rem' }}>{label}</label>
        <input className="input" value={value} onChange={e => onChange(e.target.value)} placeholder={`https://${label.toLowerCase()}.com/tu-cuenta`} />
      </div>
    </div>
  );
}

function Footer({ socials }) {
  const socialLinks = [
    { icon: Facebook, url: socials?.facebook, label: 'Facebook' },
    { icon: Instagram, url: socials?.instagram, label: 'Instagram' },
    { icon: Music2, url: socials?.tiktok, label: 'TikTok' },
    { icon: MessageCircle, url: socials?.whatsapp, label: 'WhatsApp' }
  ].filter(s => s.url);
  return (
    <footer style={{ background: 'var(--black)', color: '#fff', padding: '3rem 1.5rem 2rem', marginTop: '4rem' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--display)', fontSize: '2rem', fontWeight: 900, marginBottom: '.25rem' }}>Mayaj</div>
        <div style={{ fontSize: '.7rem', letterSpacing: '.4em', color: 'var(--rose-light)', textTransform: 'uppercase', marginBottom: '2rem' }}>Guatemala</div>
        {socialLinks.length > 0 && (
          <div style={{ display: 'flex', gap: '.75rem', justifyContent: 'center', marginBottom: '2rem' }}>
            {socialLinks.map(s => (
              <a key={s.label} href={s.url} target="_blank" rel="noopener noreferrer" style={{ width: 44, height: 44, borderRadius: '50%', background: 'rgba(255,255,255,.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', textDecoration: 'none' }}>
                <s.icon size={18} />
              </a>
            ))}
          </div>
        )}
        <p style={{ fontSize: '.8rem', color: 'rgba(255,255,255,.5)', margin: 0 }}>© {new Date().getFullYear()} Mayaj Guatemala · Perrajes tejidos a mano</p>
      </div>
    </footer>
  );
}
