# 🌸 Tienda Mayaj Guatemala

Tienda virtual de perrajes artesanales con carrito, checkout, integración con Forza Delivery, Recurrente y WhatsApp.

---

## 🚀 Opción A: Subir a Vercel (MÁS FÁCIL — recomendada)

### Paso 1: Crear cuenta de GitHub
1. Ve a https://github.com y crea una cuenta gratis
2. Una vez dentro, haz clic en el botón verde **"New repository"**
3. Nombre del repositorio: `mayaj-tienda`
4. Marca como **Public** y da clic en **"Create repository"**

### Paso 2: Subir los archivos a GitHub
1. En la página del repositorio, haz clic en **"uploading an existing file"**
2. Arrastra TODAS las carpetas y archivos de esta descarga (no solo el ZIP, descomprímelo antes)
3. Baja hasta el final, escribe "primer subida" y haz clic en **"Commit changes"**

### Paso 3: Conectar con Vercel
1. Ve a https://vercel.com y crea cuenta (usa el botón **"Continue with GitHub"**)
2. Una vez adentro, haz clic en **"Add New... → Project"**
3. Selecciona tu repositorio `mayaj-tienda` y haz clic en **"Import"**
4. Deja todos los valores por defecto y haz clic en **"Deploy"**
5. Espera 1-2 minutos... ¡Listo! Te dará un link tipo `mayaj-tienda.vercel.app`

### Paso 4: Compartir el link
Ese link `mayaj-tienda.vercel.app` es lo que compartes con tus clientes por WhatsApp, Facebook, Instagram, TikTok, etc.

---

## 🖥️ Opción B: Probar localmente antes de subirla

Si quieres probarla en tu computadora primero:

### Requisitos:
- Instalar **Node.js** desde https://nodejs.org (descarga la versión LTS)

### Pasos:
1. Abre la terminal/símbolo del sistema en la carpeta del proyecto
2. Escribe: `npm install` y presiona Enter (instala todo, tarda 2 min)
3. Escribe: `npm run dev` y presiona Enter
4. Abre en tu navegador: http://localhost:5173

---

## 🛠️ Primera configuración al abrir la tienda

### 1. Entrar al panel de administración
- Haz clic en el botón **"Admin"** (arriba a la derecha)
- Contraseña: **`mayaj2026`**

### 2. Agregar tus productos
- Pestaña **"Productos"** → **"Nuevo producto"**
- Llena: nombre, tamaño, precio, descripción, imagen
- Haz clic en **"Guardar"**
- Repite por cada perraje

### 3. Configurar datos del negocio
- Pestaña **"Configuración"**:
  - ✅ WhatsApp: `39967739` (ya está configurado)
  - ✅ Envío: `Q35` (ya está configurado)
  - ✅ URL Recurrente: ya configurada
  - 🔗 Agrega tus enlaces de Facebook, Instagram, TikTok, WhatsApp
  - 🔑 Cuando tengas el API Key de Forza, pégalo aquí

### 4. Cambiar la contraseña de admin (IMPORTANTE)
Abre el archivo `src/MayajStore.jsx`, busca la línea que dice `if (pass === 'mayaj2026')` y cámbiala por tu contraseña secreta. Luego sube los cambios a GitHub.

---

## ⚠️ IMPORTANTE sobre almacenamiento

Esta versión guarda los datos en **el navegador del usuario** (localStorage). Eso significa:

✅ **Funciona bien para:**
- Comenzar a vender rápido sin costos
- Tu panel de admin (los datos de productos y ventas se guardan en TU navegador)

⚠️ **Limitaciones:**
- Si abres el admin desde otro dispositivo o borras cache, NO verás tus ventas ni productos
- Las ventas registradas solo las ves tú en el navegador donde se hicieron

🔥 **Solución para crecer:** Cuando ya estés vendiendo bien, te recomiendo migrar a una base de datos real (como **Supabase**, que es gratis hasta cierto uso). Con eso, podrás ver todas las ventas desde cualquier dispositivo y no perderás nada. Avísame y te ayudo con la migración.

**Alternativa mientras tanto:** Siempre usa el MISMO dispositivo/navegador para administrar la tienda, y haz captura de pantalla de las ventas importantes.

---

## 📞 Cuando recibas el API Key de Forza

1. Entra al admin → Configuración
2. Pega el API key en el campo correspondiente
3. Haz clic en "Guardar"
4. Ya con eso, cada venta genera automáticamente la guía en Forza con: manual, municipio del cliente, 10 libras, COD/Estándar según corresponda, datos del cliente y "Llamar 1 hora antes"

**Nota técnica:** El endpoint exacto (`/api/guias/crear`) es un ejemplo. Cuando tengas el API key, Forza te dará la URL y formato correctos. Avísame para ajustarlo.

---

## 🆘 ¿Problemas?
- El link no funciona → Revisa que Vercel haya terminado el deploy (debe decir "Ready")
- El WhatsApp no envía → Asegúrate que el número del cliente esté en formato Guatemala (8 dígitos, sin +502)
- Perdí mis ventas → Estás usando otro navegador/dispositivo. Vuelve al original.
